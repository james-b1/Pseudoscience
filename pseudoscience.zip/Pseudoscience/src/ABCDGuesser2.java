import components.simplereader.SimpleReader;
import components.simplereader.SimpleReader1L;
import components.simplewriter.SimpleWriter;
import components.simplewriter.SimpleWriter1L;
import components.utilities.FormatChecker;

/**
 * Put a short phrase describing the program here.
 *
 * @author Put your name here
 *
 */
public final class ABCDGuesser2 {

    /**
     * No argument constructor--private to prevent instantiation.
     */
    private ABCDGuesser2() {
    }

    /**
     * Repeatedly asks the user for a positive real number until the user enters
     * one. Returns the positive real number.
     *
     * @param in
     *            the input stream
     * @param out
     *            the output stream
     * @return a positive real number entered by the user
     */
    private static double getPositiveDouble(SimpleReader in, SimpleWriter out) {
        boolean validResponse = false;
        double num = 0.0;
        while (!validResponse) {
            out.println("Pick a Positive Real Number for μ:");
            String response = in.nextLine();
            if (FormatChecker.canParseDouble(response)
                    && !(Double.parseDouble(response) < 0.0)) {
                num = Double.parseDouble(response);
                validResponse = true;
            } else {
                out.println("Response Not Valid");
            }

        }
        return num;
    }

    /**
     * Repeatedly asks the user for a positive real number not equal to 1.0
     * until the user enters one. Returns the positive real number.
     *
     * @param in
     *            the input stream
     * @param out
     *            the output stream
     * @return a positive real number not equal to 1.0 entered by the user
     */
    private static double getPositiveDoubleNotOne(SimpleReader in, SimpleWriter out) {
        boolean validResponse = false;
        double num = 0.0;
        while (!validResponse) {
            out.println("Pick a Positive Real Number Not Equal to 1");
            String response = in.nextLine();
            if (FormatChecker.canParseDouble(response)
                    && !(Double.parseDouble(response) < 0.0)
                    && Double.parseDouble(response) != 1) {
                num = Double.parseDouble(response);
                validResponse = true;
            } else {
                out.println("Response Not Valid");
            }

        }
        return num;
    }

    /**
     * Calculates the relative error of a theoretical value a number is supposed
     * to be and an actual value that was measured/calculated.
     *
     * @param theoVal
     *            the theoretical value
     * @param actualVal
     *            the actual value
     * @return the relative error of the actual value as a percent
     */
    private static double calculateRelativeError(double theoVal, double actualVal) {
        final int percent = 100;
        double res;
        res = (Math.abs(theoVal - actualVal) / actualVal) * percent;
        return res;
    }

    /**
     * Main method.
     *
     * @param args
     *            the command line arguments
     */
    public static void main(String[] args) {
        SimpleReader in = new SimpleReader1L();
        SimpleWriter out = new SimpleWriter1L();

        // Declare constants and array of potential exponents
        final int index = 16;
        final double[] exponents = { -5, -4, -3, -2, -1, (double) -1 / 2, (double) -1 / 3,
                0, (double) 1 / 4, (double) 1 / 3, (double) 1 / 2, 1, 2, 3, 4, 5 };
        /*
         * Put your main program code here;
         */

        // Call methods to get necessary inputs
        double mu = getPositiveDouble(in, out);
        double w = getPositiveDoubleNotOne(in, out);
        double x = getPositiveDoubleNotOne(in, out);
        double y = getPositiveDoubleNotOne(in, out);
        double z = getPositiveDoubleNotOne(in, out);

        // Declare and/or define necessary variables
        boolean theorySupported;
        double tempNumber, finalNumber = 0.0;
        double minError, relError;
        double a = exponents[0];
        double b = exponents[0];
        double c = exponents[0];
        double d = exponents[0];
        tempNumber = Math.pow(w, a) * Math.pow(x, b) * Math.pow(y, c) * Math.pow(z, d);
        relError = calculateRelativeError(mu, tempNumber);
        minError = relError;

        // Loop through every possible number in order to find number with smallest
        //relative error
        for (int i = 0; i < index; i++) {
            for (int j = 0; j < index; j++) {
                for (int k = 0; k < index; k++) {
                    for (int l = 0; l < index; l++) {
                        tempNumber = Math.pow(w, exponents[i]) * Math.pow(x, exponents[j])
                                * Math.pow(y, exponents[k]) * Math.pow(z, exponents[l]);
                        relError = calculateRelativeError(mu, tempNumber);
                        if (relError < minError) {
                            finalNumber = tempNumber;
                            a = exponents[i];
                            b = exponents[j];
                            c = exponents[k];
                            d = exponents[l];
                            minError = relError;
                        }
                    }
                }
            }

        }

        // Print results
        theorySupported = (minError <= 1); // Determine if relative error is within 1%
        out.println("The exponents a = " + a + ", b = " + b + ", c = " + c + ", and d = "
                + d);
        out.print("produce the number " + Math.round(finalNumber)
                + " which has a relative error of ");
        out.print(minError, 2, false);
        out.println("%.");
        if (theorySupported) {
            out.println("Therefore, the \"charming theory\" stands.");
        } else {
            out.println("Therefore, the \"charming theory\" does not stand.");
        }

        /*
         * Close input and output streams
         */
        in.close();
        out.close();

    }

}
